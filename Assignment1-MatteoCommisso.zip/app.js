const HTTP_PORT = process.env.PORT || 3000;

const express = require("express");
const exphbs = require("express-handlebars");
const path = require("path");
const fs = require("fs");

const app = express();

app.use(express.json());
app.use(express.static("public"));

app.engine(
  ".hbs",
  exphbs.engine({
    extname: ".hbs",
    defaultLayout: false,
    layoutsDir: path.join(__dirname, "/views"),
  })
);

app.set("view engine", ".hbs");
app.use(express.urlencoded({ extended: false }));

const userData = JSON.parse(fs.readFileSync("users.json"));

app.get("/", (req, res) => {
  var someData = {};

  res.render("landing", {
    data: someData,
  });
});

app.get("/signin", (req, res) => {
  res.render("signin");
});

app.post("/signin", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  if (userData[username]) {
    if (userData[username] === password) {
      res.redirect(`/home?username=${username}`);
    } else {
      // Incorrect password
      res.render("signin", {
        data: {
          error: "Invalid password",
        },
      });
    }
  } else {
    res.render("signin", {
      data: {
        error: "Not a registered username",
      },
    });
  }
});

app.get("/home", (req, res) => {
  const username = req.query.username;

  res.render("home", {
    data: { username },
  });
});

app.post("/signout", (req, res) => {
  res.redirect("/");
});

const server = app.listen(HTTP_PORT, () => {
  console.log(`Listening on port ${HTTP_PORT}`);
});
