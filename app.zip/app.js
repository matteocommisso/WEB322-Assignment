const HTTP_PORT = process.env.PORT || 3000;

const express = require("express");
const exphbs = require("express-handlebars");
const path = require("path");
const fs = require("fs");
const session = require("express-session");
const cookieParser = require("cookie-parser");

const app = express();

app.use(express.json());
app.use(express.static("public"));
app.use(cookieParser());
app.use(
  session({
    secret: "your-secret-key",
    resave: true,
    saveUninitialized: true,
    cookie: {
      maxAge: 180000, // 3 minutes
    },
  })
);

const sessionTimeout = (req, res, next) => {
  if (req.session.lastAccess && Date.now() - req.session.lastAccess > 180000) {
    req.session.destroy();
    res.clearCookie("loggedIn");
    res.clearCookie("username");
    return res.redirect("/signin");
  }
  req.session.lastAccess = Date.now();
  next();
};

app.use(sessionTimeout);

app.engine(
  ".hbs",
  exphbs.engine({
    extname: ".hbs",
    defaultLayout: false,
    layoutsDir: path.join(__dirname, "/views"),
    partialsDir: path.join(__dirname, "/views/partials"),
  })
);

app.set("view engine", ".hbs");
app.use(express.urlencoded({ extended: false }));

const userData = JSON.parse(fs.readFileSync("users.json"));
let bookData = require("./books.json");

app.get("/", (req, res) => {
  var someData = {};

  res.render("landing", {
    data: someData,
  });
});

app.get("/signin", (req, res) => {
  res.render("signin");
});

app.post("/signin", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  if (userData[username]) {
    if (userData[username] === password) {
      req.session.loggedIn = true;
      req.session.username = username;

      res.cookie("loggedIn", true);
      res.cookie("username", username);

      res.redirect(`/home?username=${username}`);
    } else {
      res.render("signin", {
        data: {
          error: "Invalid password",
        },
      });
    }
  } else {
    res.render("signin", {
      data: {
        error: "Not a registered username",
      },
    });
  }
});

const checkLoggedIn = (req, res, next) => {
  if (req.session.loggedIn) {
    next();
  } else {
    res.redirect("/");
  }
};

app.get("/home", checkLoggedIn, (req, res) => {
  const username = req.query.username;

  const availableBooks = bookData.filter((book) => book.available === true);
  const unavailableBooks = bookData.filter((book) => book.available === false);

  res.render("home", {
    data: {
      username,
      books: {
        available: availableBooks,
        unavailable: unavailableBooks,
      },
    },
  });
});

app.post("/submit", (req, res) => {
  const selectedBooks = req.body.items;

  if (req.body.button === "Borrow") {
    bookData.forEach((book) => {
      if (selectedBooks.includes(book.title)) {
        book.available = false;
      }
    });
  } else if (req.body.button === "Return") {
    bookData.forEach((book) => {
      if (selectedBooks.includes(book.title)) {
        book.available = true;
      }
    });
  }

  res.redirect(`/home?username=${req.session.username}`);
});

app.post("/signout", (req, res) => {
  req.session.destroy();
  res.clearCookie("loggedIn");
  res.clearCookie("username");

  res.redirect("/");
});

const server = app.listen(HTTP_PORT, () => {
  console.log(`Listening on port ${HTTP_PORT}`);
});
